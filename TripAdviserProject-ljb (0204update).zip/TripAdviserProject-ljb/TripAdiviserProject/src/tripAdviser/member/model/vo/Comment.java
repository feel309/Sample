package tripAdviser.member.model.vo;

import java.util.Date;

public class Comment {
	private int trvNo;
	private String memberId;
	private int trvEvaluation;
	private String comment_title;
	private String comment;
	private Date commentDate;
	
	public Comment() {}
}
