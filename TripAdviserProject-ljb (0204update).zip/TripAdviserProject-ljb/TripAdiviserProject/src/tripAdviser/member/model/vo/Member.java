package tripAdviser.member.model.vo;

import java.util.Date;

public class Member {
	public String memberId;
	public String memberPw;
	public int memberGrade;
	public String email;
	public String name;
	public int postalCode;
	public String address;
	public String addressDetail;
	public String phone;
	public Date date;
	
	public Member () {}
}
