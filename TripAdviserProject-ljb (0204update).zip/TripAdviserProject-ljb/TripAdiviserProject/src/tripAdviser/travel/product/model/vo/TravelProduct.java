package tripAdviser.travel.product.model.vo;

import java.util.Date;

public class TravelProduct {
	private int trvNo;
	private String trvTitle;
	private String trvProvince;
	private String trvCity;
	private String trvAddress;
	private Date trvDateStart;
	private Date trvDateEnd;
	private String trvReview;
	private String trvCategory;
	private String trvGps;
	private Date trvDate;
	private String memberId;
	
	public TravelProduct() {}
}
