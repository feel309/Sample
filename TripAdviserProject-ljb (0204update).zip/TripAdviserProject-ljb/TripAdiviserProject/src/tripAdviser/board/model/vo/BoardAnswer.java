package tripAdviser.board.model.vo;

import java.util.Date;

public class BoardAnswer {
	//댓글 객체
	private int boardNo;
	private String content;
	private Date boardDate;
	
	public BoardAnswer() {}
	
}
