package tripAdviser.board.model.vo;

import java.util.Date;

public class Board {
	public int boardNo;
	public String memberId;
	public String title;
	public String content;
	public int hits;
	public Date boardDate;
}
